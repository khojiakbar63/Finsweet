### Finsweet Agency

- Technical Documentation 
- Figma file : https://www.figma.com/file/KkEvi4lJ3CPsRT4mcY46d7/Finsweet-Agency-(Copy)?type=design&node-id=1%3A1755&mode=dev&t=FL1yyD0QOkVHFIyU-1

### Files

- Folder structure +
- Export (fonts , images , icons ) +


### Coding

- container +
- universal class * main styles +

###### Home page (index.html)

- HEADER  +
- INTRO  
- Our Clients
- ABOUT US
- Our expertise
- Our Services
- Our Process
- Customers
- NEWSLETTER
- Footer
